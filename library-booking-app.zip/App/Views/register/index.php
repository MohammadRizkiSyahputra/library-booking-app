<!-- Disini za buat styling css sama atur2 margin lah -->

<div>
  <h2>Register</h2>
  <p>Choose your registration type:</p>
  
  <div>
    <a href="/register/mahasiswa">Register as Mahasiswa</a>
  </div>
  
  <div>
    <a href="/register/dosen">Register as Dosen</a>
  </div>
  
  <p>Already have an account? <a href="/login">Login</a></p>
</div>
