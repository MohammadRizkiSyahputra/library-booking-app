<?php use App\Core\App; ?>

<!-- Disini za buat edit2 - Error 404 page styling -->

<div>
  <h1>404</h1>
  <h2>Not Found</h2>
  <p>We don't seem to find what you're looking for</p>
  <a href="/login">Go to Login</a>
</div>
