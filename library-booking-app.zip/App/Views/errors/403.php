<?php use App\Core\App; ?>

<!-- Disini za buat edit2 - Error 403 page styling -->

<div>
  <h1>403</h1>
  <h2>Forbidden</h2>
  <p>You are not authorized to access this page.</p>
  <a href="/login">Go to Login</a>
</div>
