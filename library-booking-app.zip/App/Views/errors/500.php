<?php use App\Core\App; ?>

<!-- Disini za buat edit2 - Error 500 page styling -->

<div>
  <h1>500</h1>
  <h2>Server Error</h2>
  <p>Something went wrong on our end</p>
  <a href="/login">Go to Login</a>
</div>
