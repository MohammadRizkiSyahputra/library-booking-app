/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./App/Views/**/*.php",
    "./App/Core/Form/**/*.php",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
